// ============================================================
// api/payment.js — Razorpay Backend (Vercel Edge Function)
// Razorpay SECRET KEY sirf yahan hai — frontend mein nahi!
// 2 endpoints handle karta hai:
//   POST /api/payment?action=create  — order banao
//   POST /api/payment?action=verify  — payment verify karo
// ============================================================

import crypto from 'crypto';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  const { action } = req.query;

  // ✅ Yeh keys Vercel Dashboard mein daalo:
  // RAZORPAY_KEY_ID     = rzp_live_xxxxxxxxxx
  // RAZORPAY_KEY_SECRET = xxxxxxxxxxxxxxxx
  const KEY_ID     = process.env.RAZORPAY_KEY_ID;
  const KEY_SECRET = process.env.RAZORPAY_KEY_SECRET;

  if (!KEY_ID || !KEY_SECRET) {
    return res.status(500).json({ error: 'Razorpay keys not configured' });
  }

  // ── 1. ORDER CREATE ──────────────────────────────────────
  if (action === 'create') {
    try {
      const { plan, userEmail, userName } = req.body;

      // Prices in cents — monthly equivalent shown to user
      // For 6month/yearly: charge total upfront
      const planPrices = {
        pro_monthly:  2900,               // $29/mo — charge monthly
        pro_6month:   2500 * 6,           // $25/mo x 6 = $150 upfront
        pro_yearly:   2000 * 12,          // $20/mo x 12 = $240 upfront
        biz_monthly:  7900,               // $79/mo — charge monthly
        biz_6month:   6700 * 6,           // $67/mo x 6 = $402 upfront
        biz_yearly:   5500 * 12,          // $55/mo x 12 = $660 upfront
        // Legacy keys support
        pro:      2900,
        business: 7900,
        annual:   1900,
      };

      const amount = planPrices[plan];
      if (!amount) return res.status(400).json({ error: 'Invalid plan' });

      // Razorpay order create karo
      const authHeader = Buffer.from(`${KEY_ID}:${KEY_SECRET}`).toString('base64');
      const rzpRes = await fetch('https://api.razorpay.com/v1/orders', {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${authHeader}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: amount * 100,    // paise mein (cents * 100)
          currency: 'USD',
          receipt: `receipt_${plan}_${Date.now()}`,
          notes: {
            plan,
            userEmail: userEmail || '',
            userName:  userName  || '',
          },
        }),
      });

      if (!rzpRes.ok) {
        const err = await rzpRes.json();
        return res.status(rzpRes.status).json({ error: err.error?.description || 'Order creation failed' });
      }

      const order = await rzpRes.json();

      // Frontend ko order_id + key_id bhejo (secret nahi!)
      return res.status(200).json({
        order_id:  order.id,
        amount:    order.amount,
        currency:  order.currency,
        key_id:    KEY_ID,      // Frontend ko sirf key_id chahiye — secret nahi
        plan,
      });

    } catch (err) {
      console.error('Order create error:', err);
      return res.status(500).json({ error: 'Failed to create order' });
    }
  }

  // ── 2. PAYMENT VERIFY ────────────────────────────────────
  if (action === 'verify') {
    try {
      const {
        razorpay_order_id,
        razorpay_payment_id,
        razorpay_signature,
        plan,
        userId,
      } = req.body;

      // Signature verify karo — tamper detection
      const body      = razorpay_order_id + '|' + razorpay_payment_id;
      const expected  = crypto
        .createHmac('sha256', KEY_SECRET)
        .update(body)
        .digest('hex');

      if (expected !== razorpay_signature) {
        return res.status(400).json({ error: 'Invalid payment signature — possible fraud' });
      }

      // Payment genuine hai — success return karo
      // (Supabase plan update frontend pe hoga ya yahan bhi kar sakte ho)
      return res.status(200).json({
        success:    true,
        payment_id: razorpay_payment_id,
        order_id:   razorpay_order_id,
        plan,
        userId,
      });

    } catch (err) {
      console.error('Verify error:', err);
      return res.status(500).json({ error: 'Verification failed' });
    }
  }

  return res.status(400).json({ error: 'Invalid action. Use ?action=create or ?action=verify' });
}
