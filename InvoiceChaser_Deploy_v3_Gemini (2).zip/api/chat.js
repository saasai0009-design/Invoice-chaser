// ============================================================
// api/chat.js — Gemini AI Backend (Vercel Edge Function)
// Yeh file /api/chat pe automatically backend ban jaati hai
// Gemini key sirf Vercel environment mein hoti hai — safe!
// ============================================================

export default async function handler(req, res) {
  // Only POST allowed
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // CORS — apna domain yahan daalo deploy ke baad
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  try {
    const { prompt, tone, invoiceData } = req.body;

    if (!prompt && !invoiceData) {
      return res.status(400).json({ error: 'prompt or invoiceData required' });
    }

    // Build prompt from invoiceData if sent directly
    const finalPrompt = prompt || buildPrompt(invoiceData, tone);

    // ✅ GEMINI_KEY — Vercel Dashboard mein daalo
    // Settings → Environment Variables → GEMINI_KEY
    // Google AI Studio se key lo: https://aistudio.google.com/apikey
    const GEMINI_KEY = process.env.GEMINI_KEY;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_KEY}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: finalPrompt }] }],
          generationConfig: {
            maxOutputTokens: 400,
            temperature: 0.7,
          },
        }),
      }
    );

    if (!response.ok) {
      const err = await response.json();
      return res.status(response.status).json({ error: err.error?.message || 'Gemini API error' });
    }

    const geminiData = await response.json();

    // Gemini response ko Anthropic-style format mein convert karo
    // Taaki frontend code change na karna pade
    const text = geminiData.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const data = {
      content: [{ type: 'text', text }],
    };

    return res.status(200).json(data);

  } catch (error) {
    console.error('Chat API error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

// Helper — prompt builder
function buildPrompt(inv, tone) {
  const toneMap = {
    friendly: 'warm, friendly and understanding. Like a colleague reminding a friend. Polite, no pressure.',
    professional: 'professional, formal and businesslike. Clear and respectful.',
    firm: 'firm, direct and serious. Make the urgency absolutely clear.',
  };
  return `Write an invoice follow-up email. Respond ONLY in this exact format:
SUBJECT: [subject line]
BODY:
[email body]

Details:
- Client: ${inv.client}
- Invoice: ${inv.invno}
- Amount: $${Number(inv.amount).toLocaleString()}
- Days overdue: ${inv.daysOverdue}
- Service: ${inv.desc || 'professional services'}
- Payment link: ${inv.paylink || '(not provided)'}
- Reminder number: ${inv.sent + 1}
- Tone: ${toneMap[tone] || toneMap.friendly}

Rules: Under 110 words. Use actual values. Sign as: Best regards, [Your Name]`;
}
